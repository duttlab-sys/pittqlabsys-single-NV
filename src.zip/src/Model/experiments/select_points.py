# Created by Gurudev Dutt <gdutt@pitt.edu> on 2023-08-17
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

import numpy as np
from math import floor
import pyqtgraph as pg
from scipy.spatial import KDTree
import time
import random
from src.core import Experiment, Parameter
from PyQt5.QtGui import QBrush, QPen
from PyQt5.QtWidgets import QGraphicsEllipseItem
from pyqtgraph import functions as fn
from PyQt5.QtCore import Qt

class SelectPoints(Experiment):
    """
Experiment to select points on an image. The selected points are saved and can be used in a superexperiment to iterate over.
    """
    _DEFAULT_SETTINGS = [
        Parameter('patch_size', 0.003),
        Parameter('type', 'free', ['free', 'square', 'line', 'ring', 'arc']),
        Parameter('Nx', 5, int, 'number of points along x (type: square) along line (type: line)'),
        Parameter('Ny', 5, int, 'number of points along y (type: square)'),
        Parameter('randomize', False, bool, 'Determines if points should be randomized')
    ]
    _DEVICES = {}
    _EXPERIMENTS = {}
    def __init__(self, devices = None, experiments = None, name = None, settings = None, log_function = None, data_path = None):
        """
        Select points by clicking on an image
        """
        Experiment.__init__(self, name, settings = settings, devices = devices, sub_experiments= experiments, log_function= log_function, data_path = data_path)
        self.text = []
        self.patch_collection = None
        self.plot_settings = {}

    def _function(self):
        """
        Waits until stopped to keep experiment live. Gui must handle calling of Toggle_NV function on mouse click.
        If using with an experiment iterator use skip button to stop and go to next experiment
        """
        self.log('!!! If using SelectPoints in an Iterator use SKIP Button to finish !!!')
        self.data = {'nv_locations': [], 'image_data': None, 'extent': None, 'pt_indices': []}
        #two progress signals here ensure that plot is called so that SelectPoints can properly get Image from previous experiment in iterator
        self.progress = 49
        self.updateProgress.emit(self.progress)
        time.sleep(0.2)
        self.progress = 50
        self.updateProgress.emit(self.progress)
        # keep experiment alive while NVs are selected
        while not self._abort:
            time.sleep(1)

    def plot(self, figure_list):
        '''
        Plots a dot on top of each selected NV, with a corresponding number denoting the order in which the NVs are
        listed.
        Precondition: must have a GraphicsLayout with a PlotItem and a Colorbar. The PlotItem houses the ImageItem / the image data.
                      Only works if there is precisely one of each in the correct spot. See ExampleExperiment 2D plot for correct setup.
        Args:
            figure_list:
        '''
        # if there is not image data get it from the current plot
        if not self.data == {} and self.data['image_data'] is None:
            plot = figure_list[0].getItem(row=0,col=0)
            x_axis = plot.getAxis('bottom')
            y_axis = plot.getAxis('left')
            self.plot_settings['xlabel'] = x_axis.label.toPlainText()
            self.plot_settings['ylabel'] = y_axis.label.toPlainText()

            if plot.items is not None:
                for item in plot.items:
                    if isinstance(item, pg.ImageItem):
                        image = item
                        image_data = item.image
            else:
                Experiment.plot(self, figure_list)
                print('NO IMAGE FOUND')
                raise

            self.data['image_data'] = image_data

            rect = image.boundingRect()
            top_left = image.mapToView(rect.topLeft())
            bottom_right = image.mapToView(rect.bottomRight())
            xmin = top_left.x()
            xmax = bottom_right.x()
            ymin = top_left.y()
            ymax = bottom_right.y()
            self.data['extent'] = np.array([xmin, xmax, ymin, ymax])

            self.plot_settings['cmap'] = plot.parentItem().getItem(row=0,col=1).colorMap().name
            self.plot_settings['title'] = plot.titleLabel.text

            #pyqt graph does not have a method for getting the interpolation...just using nearest for now
            #self.plot_settings['interpol'] = axes.images[0].get_interpolation()

        Experiment.plot(self, figure_list)

    #must be passed figure with image plot on first axis
    def _plot(self, axes_list):
        '''
        Plots a copy of the image from previous experiment on bottom graph (figure_list[0] and axes_list[0])
        Precondition: must have an existing image in figure_list[0] to plot over
        Args:
            figure_list:
        '''
        def create_img(add_colorbar=True):
            axes.clear()
            self.sp_image = pg.ImageItem(self.data['image_data'], interpolation='nearest', extent=extent)
            #get shape of image to calculate indices of selected points
            self.img_len_x, self.img_len_y = np.shape(self.data['image_data'])
            self.sp_image.setLevels(levels)
            self.sp_image.setRect(pg.QtCore.QRectF(extent[0], extent[2], extent[1] - extent[0], extent[3] - extent[2]))

            axes.addItem(self.sp_image)
            axes.setLabel('left', self.plot_settings['ylabel'])
            axes.setLabel('bottom', self.plot_settings['xlabel'])
            axes.setTitle('Selet Points on: '+self.plot_settings['title'])
            axes.setAspectLocked(True)

            if add_colorbar:
                self.colorbar = pg.ColorBarItem(values=(levels[0], levels[1]), colorMap=self.plot_settings['cmap'])
                # layout is housing the PlotItem that houses the ImageItem. Add colorbar to layout so it is properly saved when saving dataset
                layout = axes.parentItem()
                layout.addItem(self.colorbar)
            self.colorbar.setImageItem(self.sp_image)

        axes = axes_list[0]
        if self.plot_settings:
            extent = self.data['extent']
            levels = [np.min(self.data['image_data']),np.max(self.data['image_data'])]

            if self._plot_refresh:
                #if plot refresh is true the ImageItem has been deleted and needs recreated
                create_img()
            else:
                try:
                    self.sp_image.setImage(self.data['image_data'], autoLevels=False)
                    self.sp_image.setLevels(levels)
                    self.colorbar.setLevels(levels)
                except RuntimeError:
                    #sometimes when clicking other experiments ImageItem is deleted but _plot_refresh is false. This ensures the image can be replotted
                    create_img(add_colorbar=False)

        self._update(axes_list)

    def _update(self, axes_list):
        '''
        Handles plotting text and circles over clicked points
        '''
        patch_size = self.settings['patch_size']
        axes = axes_list[0]

        # Clear previous plotted ellipses and labels
        if hasattr(self, 'point_ellipses'):
            for ellipse in self.point_ellipses:
                axes.removeItem(ellipse)
        if hasattr(self, 'text_items'):
            for text in self.text_items:
                axes.removeItem(text)

        ellipses_list = []
        text_labels = []

        if self.data['nv_locations'] is not None:
            if len(self.data['nv_locations']) > 400:
                print("Cannot select more than 400 locations in image!")
                raise RuntimeError("Cannot select more than 400 locations in image!")

            for index, pt in enumerate(self.data['nv_locations']):
                xmin = self.data['extent'][0]
                xmax = self.data['extent'][1]
                ymin = self.data['extent'][2]
                ymax = self.data['extent'][3]
                x, y = pt
                # only want to plot points if they are in the image region
                if xmin <= x <= xmax and ymin <= y <= ymax:
                    #add a circle over each clicked point
                    r = patch_size / 2
                    ellipse = QGraphicsEllipseItem(x-r,y-r,patch_size,patch_size)
                    ellipse.setBrush(QBrush(fn.mkColor('r')))
                    ellipse.setPen(QPen(Qt.NoPen))
                    ellipse.setZValue(9)
                    axes.addItem(ellipse)
                    ellipses_list.append(ellipse)

                    #at the index number over each clicked point
                    text = pg.TextItem(text=str(index), color='w', anchor=(0.5, 0.5))
                    text.setPos(pt[0], pt[1])
                    text.setZValue(10)
                    axes.addItem(text)
                    text_labels.append(text)

            self.text_items = text_labels
            self.point_ellipses = ellipses_list

    def toggle_NV(self, pt):
        '''
        If there is not currently a selected NV within self.settings[patch_size] of pt, adds it to the selected list. If
        there is, removes that point from the selected list.
        Args:
            pt: the point to add or remove from the selected list
        Poststate: updates selected list
        '''
        def index_point(x,y,xmin,xmax,ymin,ymax):
            #takes inputed point and calculates x,y index in image data
            x_dis_from_edge = x - xmin
            y_dis_from_edge = y - ymin
            x_tot_dis = xmax - xmin
            y_tot_dis = ymax - ymin
            # use floor as rounding down compensates for index starting at 0
            x_index = floor(self.img_len_x * x_dis_from_edge / x_tot_dis)
            y_index = floor(self.img_len_y * y_dis_from_edge / y_tot_dis)
            return x_index, y_index

        xmin = self.data['extent'][0]
        xmax = self.data['extent'][1]
        ymin = self.data['extent'][2]
        ymax = self.data['extent'][3]
        x, y = pt
        # only want to points if they are in the image region
        if xmin <= x <= xmax and ymin <= y <= ymax:
            if not self.data['nv_locations']: #if self.data is empty so this is the first point
                self.data['nv_locations'].append(pt)
                index = index_point(x, y, xmin, xmax, ymin, ymax)
                self.data['pt_indices'].append(index)
                self.log(f'Selected NV at (x,y) = ({x:.2f},{y:.2f}) and index (i,j) = {index}')
                self.data['image_data'] = None # clear image data
            else:
                # use KDTree to find NV closest to mouse click
                tree = KDTree(self.data['nv_locations'])
                #does a search with k=1, that is a search for the nearest neighbor, within distance_upper_bound
                d, i = tree.query(pt,k = 1, distance_upper_bound = self.settings['patch_size'])

                # removes NV if previously selected
                if not np.isinf(d):
                    self.log(f'Removed NV at (x,y) = ({self.data["nv_locations"][i]}) and index (i,j) = {self.data["pt_indices"][i]}')
                    self.data['nv_locations'].pop(i)
                    self.data['pt_indices'].pop(i)
                # adds NV if not previously selected
                else:
                    self.data['nv_locations'].append(pt)
                    index = index_point(x,y,xmin,xmax,ymin,ymax)
                    self.data['pt_indices'].append(index)
                    self.log(f'Selected NV at (x,y) = ({x:.2f},{y:.2f}) and index (i,j) = {index}')

                # randomize
                if self.settings['randomize']:
                    self.log('warning! randomize not avalable when manually selecting points')

            #if type is not free we calculate the total points of locations from the first selected points
            #not adding point indexing for specific geometries as idk how they are to be used in future -- Dylan Staples
            if self.settings['type'] == 'square' and len(self.data['nv_locations'])>1:
                # here we create a rectangular grid, where pts a and be define the top left and bottom right corner of the rectangle
                Nx, Ny = self.settings['Nx'], self.settings['Ny']
                pta = self.data['nv_locations'][0]
                ptb = self.data['nv_locations'][1]
                tmp  = np.array([[[pta[0] + 1.0*i*(ptb[0]-pta[0])/(Nx-1), pta[1] + 1.0*j*(ptb[1]-pta[1])/(Ny-1)] for i in range(Nx)] for j in range(Ny)])
                nv_pts = np.reshape(tmp, (Nx * Ny, 2))

                # randomize
                if self.settings['randomize']:
                    random.shuffle(nv_pts)  # shuffles in place

                self.data['nv_locations'] = nv_pts
                self.stop()

            elif self.settings['type'] == 'line' and len(self.data['nv_locations'])>1:
                # here we create a straight line between points a and b
                N = self.settings['Nx']
                pta = self.data['nv_locations'][0]
                ptb = self.data['nv_locations'][1]
                nv_pts = [np.array([pta[0] + 1.0*i*(ptb[0]-pta[0])/(N-1), pta[1] + 1.0*i*(ptb[1]-pta[1])/(N-1)]) for i in range(N)]

                # randomize
                if self.settings['randomize']:
                    random.shuffle(nv_pts)  # shuffles in place

                self.data['nv_locations'] = nv_pts
                self.stop()

            elif self.settings['type'] == 'ring' and len(self.data['nv_locations'])>1:
                # here we create a circular grid, where pts a and be define the center and the outermost ring
                Nx, Ny = self.settings['Nx'], self.settings['Ny']
                pt_center = self.data['nv_locations'][0] # center
                pt_outer = self.data['nv_locations'][1] # outermost ring
                # radius of outermost ring:
                rmax = np.sqrt((pt_center[0] - pt_outer[0]) ** 2 + (pt_center[1] - pt_outer[1]) ** 2)

                # angles
                angles = np.linspace(0, 2 * np.pi, Nx+1)[0:-1]
                # create points on rings
                nv_pts = []
                for r in np.linspace(rmax, 0, Ny + 1)[0:-1]:
                    for theta in angles:
                        nv_pts += [[r * np.sin(theta)+pt_center[0], r * np.cos(theta)+pt_center[1]]]

                # randomize
                if self.settings['randomize']:
                    coarray = list(zip(nv_pts, angles))
                    random.shuffle(coarray)  # shuffles in place
                    nv_pts, angles = zip(*coarray)

                self.data['nv_locations'] = np.array(nv_pts)
                self.data['angles'] = np.array(angles)* 180 / np.pi
                self.data['ring_data'] = [pt_center, pt_outer]
                self.stop()

            elif self.settings['type'] == 'arc' and len(self.data['nv_locations']) > 3:
                # here we create a circular grid, where pts a and be define the center and the outermost ring
                Nx, Ny = self.settings['Nx'], self.settings['Ny']
                pt_center = self.data['nv_locations'][0]  # center
                pt_start = self.data['nv_locations'][1]  # arc point one (radius)
                pt_dir = self.data['nv_locations'][2]  # arc point two (direction)
                pt_end = self.data['nv_locations'][3]  # arc point three (angle)

                # radius of outermost ring:
                rmax = np.sqrt((pt_center[0] - pt_start[0]) ** 2 + (pt_center[1] - pt_start[1]) ** 2)
                angle_start = np.arctan((pt_start[1] - pt_center[1]) / (pt_start[0] - pt_center[0]))
                # arctan always returns between -pi/2 and pi/2, so adjust to allow full range of angles
                if ((pt_start[0] - pt_center[0]) < 0):
                    angle_start += np.pi

                angle_end = np.arctan((pt_end[1] - pt_center[1]) / (pt_end[0] - pt_center[0]))
                # arctan always returns between -pi/2 and pi/2, so adjust to allow full range of angles
                if ((pt_end[0] - pt_center[0]) < 0):
                    angle_end += np.pi

                if pt_dir[0] < pt_start[0]:
                    # counter-clockwise: invert the order of the angles
                    angle_start, angle_end = angle_end, angle_start

                if angle_start > angle_end:
                    # make sure that start is the smaller
                    # (e.g. angle_start= 180 deg and angle_end =10, we want to got from 180 to 370 deg)
                    angle_end += 2 * np.pi

                # create points on arcs
                nv_pts = []
                for r in np.linspace(rmax, 0, Ny + 1)[0:-1]:
                    for theta in np.linspace(angle_start, angle_end, Nx, endpoint=True):
                        nv_pts += [[r * np.cos(theta) + pt_center[0], r * np.sin(theta) + pt_center[1]]]

                # randomize
                if self.settings['randomize']:
                    coarray = list(zip(nv_pts, np.linspace(angle_start, angle_end, Nx, endpoint=True)))
                    random.shuffle(coarray)  # shuffles in place
                    nv_pts, angles = zip(*coarray)
                else:
                    angles = np.linspace(angle_start, angle_end, Nx, endpoint=True)
                self.data['nv_locations'] = np.array(nv_pts)
                self.data['arc_data'] = [pt_center, pt_start, pt_end]
                self.data['angles'] = np.array(angles) * 180 / np.pi
                self.stop()

if __name__ == '__main__':
    experiment, failed, instr = Experiment.load_and_append({'SelectPoints':'SelectPoints'})
    print(experiment)
    print(failed)
    print(instr)